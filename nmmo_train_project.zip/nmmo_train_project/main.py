import ray
import ray.rllib.agents.ppo as ppo
from ray.tune.logger import pretty_print
import tqdm
import json5
import ray.tune as tune
import gym
import gym.spaces as spaces
import numpy as np
from ray.tune.registry import register_env
from TrainEnv import MyTrainEnv

##### register env
def trainenv_creator(env_config):
    return MyTrainEnv(env_config)


env_config={
    "teams": ["RandomTeam",
              "MeanderTeam",
              "ForageNoExploreTeam",
              "ForageTeam",
              "CombatTeam",
              "CombatNoExploreTeam",
              "CombatTribridTeam"
              ]
}

register_env("MyTrainEnv", trainenv_creator)
algo_config = {
                "framework": "torch",
                "env_config": env_config,
                "model": {
                    "fcnet_hiddens": [],
                    "conv_filters": [[64, [3, 3], 2], [128, [4, 4], 2], [256, [4, 4], 3], [512, [4, 4], 3], [1024, [3, 3], 1]],
                    "conv_activation": "relu",
                    "post_fcnet_hiddens": [512, 512, 256],
                    "post_fcnet_activation": "relu"
                            },

                    "log_level": "INFO",

                    "num_workers": 1,
                    "num_envs_per_worker": 1,
                    "rollout_fragment_length": 128,
                    "train_batch_size": 128,
                    "batch_mode": "truncate_episodes",

                    "gamma": 0.99,
                    "train_batch_size": 128,

                    "ignore_worker_failures": True,
                    "recreate_failed_workers": True,

                    "evaluation_interval": 1000,
                    "evaluation_duration": 10,
                    "evaluation_duration_unit": "episodes",

                    # lr
                    "lr": 0.0005,

                    "explore": True,

                    # gpu settings
                    "num_gpus": 0.6,
                    "num_cpus_per_worker": 2,
                    "num_gpus_per_worker": 0.6,
                }

trainer = ppo.PPOTrainer(env="MyTrainEnv", config=algo_config)
MAX_UPDATE = 100000
# MAX_STEPS = MAX_UPDATE * 128
for i in range(MAX_UPDATE):
    result = trainer.train()
    print(pretty_print(result))
    if i % 5000 == 0:
        checkpoint = trainer.save()
        print("checkpoint saved at", checkpoint)
# 查看模型
# model = trainer.get_policy().model
# print(model)