from ijcai2022nmmo import CompetitionConfig, scripted, TeamBasedEnv, Team
import nmmo
import numpy as np
import copy
import gym
from gym import spaces
from nmmo.io import action
from MyTeam import MyAwesomeTeam

class MyTrainEnv(gym.Env):
    def __init__(self, env_config: dict):
        self.config = CompetitionConfig()
        self.team_env = TeamBasedEnv(self.config)
        self.env_config = env_config
        # observation_space = [spaces.MultiDiscrete(2*np.ones((129,129),dtype=np.int32))]*8
        self.observation_space = spaces.Tuple(
            (spaces.Box(low=-np.infty, high=np.infty, shape=(129, 129, 40), dtype=np.float32),
             spaces.Box(low=-np.infty, high=np.infty, shape=(88,), dtype=np.float32)
             ))
        self.action_space = spaces.Box(low=-np.infty, high=np.infty, shape=(80,), dtype=np.float32)

    def reset(self):
        self.obs_by_team = self.team_env.reset()
        #         print(self.obs_by_team)
        self.n_tick = 0
        ##### establish the teams:
        self.teams = []
        self.teams += [MyAwesomeTeam("MyTeam", self.config)]
        team_config = self.env_config["teams"]
        ### 随机生成不同的配比
        ### total 7 types
        type_num = len(team_config)
        for team_index in range(15):
            team_index_type = np.random.randint(low=0,high=type_num)
            designed_team = getattr(scripted, team_config[team_index_type])
            self.teams += [designed_team( "team"+f"-{team_index+1}"  , self.config)]


        for team in self.teams:
            team.reset()

        # myteam population id = 0
        obs_to_myteam = self.obs_by_team[0]

        new_obs = self.teams[0].update_map(obs_to_myteam)
        return new_obs

    def step(self, action):

        ######## reward
        def cal_rwd(init, seg1, seg2, seg3, prev, curr):
            k = [4 / (seg1 - init), 6 / (seg2 - seg1), 11 / (seg3 - seg2)]
            seg = [seg1, seg2, seg3]

            rwd = 0
            for i in range(3):
                if prev < seg[i]:
                    incre = min(curr - prev, seg[i] - prev)
                    rwd += k[i] * incre
                    prev += incre
                    if prev == curr:
                        return rwd

            return rwd

        def find_exploration(exploration_map):
            if exploration_map.sum() == 0:
                return 0
            x, y = np.where(exploration_map == 1)
            return max(np.max(x) - np.min(x), np.max(y) - np.min(y))

        actions = {}
        ####### convert the output of the policy into the true action
        new_my_action = self.teams[0].act(action)

        actions[0] = new_my_action
        ############

        ####### obtain the actions of other teams
        for team_index in range(1, 16):
            if self.obs_by_team.get(team_index):
                other_actions = self.teams[team_index].act(self.obs_by_team[team_index])
            else:
                other_actions = {}
            actions[team_index] = other_actions
        self.obs_by_team_all = self.team_env.step(actions)
        self.obs_by_team = self.obs_by_team_all[0]
        if self.obs_by_team.get(0) != None:
            obs_to_myteam = self.obs_by_team[0]

            new_my_obs = self.teams[0].update_map(obs_to_myteam)

            self.n_tick += 1
            if self.n_tick < 1024:
                done = False
            else:
                done = True

            info = {}

            ### hunting and fishing 21
            rwd_hunting = cal_rwd(10, 20, 35, 50, self.teams[0].last_global_information["hunting_level"],
                                  self.teams[0].global_information["hunting_level"])
            rwd_fishing = cal_rwd(10, 20, 35, 50, self.teams[0].last_global_information["fishing_level"],
                                  self.teams[0].global_information["fishing_level"])
            rwd_resources = (rwd_hunting + rwd_fishing) / 2

            ### defeat players 21
            rwd_kill = cal_rwd(0, 1, 3, 6, self.teams[0].last_global_information["kill_opponent_num"],
                               self.teams[0].global_information["kill_opponent_num"])
            # print("kill_num_prev", self.teams[0].last_global_information["kill_opponent_num"])
            # print("kill_num_curr", self.teams[0].global_information["kill_opponent_num"])
            ### exploration 21
            for idx in range(8):
                exploration_map = self.teams[0].global_map["agents"]["layers"][:, :, idx * 2 + 1]
                self.teams[0].global_information["exploration"] = max(find_exploration(exploration_map),
                                                                      self.teams[0].global_information["exploration"])
            rwd_exploration = cal_rwd(0, 32, 64, 127, self.teams[0].last_global_information["exploration"],
                                      self.teams[0].global_information["exploration"])
            #             self.teams[0].last_global_information["exploration"] = self.teams[0].global_information["exploration"]

            ### food and water
            rwd_food_and_water = 0
            for idx in range(8):
                food = self.teams[0].global_map['agents']['vectors'][idx * 11 + 2]
                water = self.teams[0].global_map['agents']['vectors'][idx * 11 + 3]
                if food < 0.3 * self.teams[0].global_information["hunting_level"]:
                    rwd_food_and_water += -0.02
                if water < 0.3 * self.teams[0].global_information["fishing_level"]:
                    rwd_food_and_water += -0.02

            ### equipment
            rwd_equip = 0
            if self.teams[0].global_information['kill_npc_level'] > self.teams[0].last_global_information[
                'kill_npc_level']:
                rwd_equip = cal_rwd(0, 1, 10, 20, self.teams[0].last_global_information["kill_npc_level"],
                                    self.teams[0].global_information["kill_npc_level"])

            ### level
            alive = False
            rwd_level = 0
            for idx in range(8):
                level = self.teams[0].global_map['agents']['vectors'][idx * 11 + 0]
                if level > 0:
                    alive = True
                self.teams[0].global_information['level'] = max(self.teams[0].global_information['level'], level)
            rwd_level += (self.teams[0].global_information['level'] - self.teams[0].last_global_information[
                'level']) * 21 / 80
            self.teams[0].last_global_information['level'] = self.teams[0].global_information['level']

            ### alive
            rwd_alive = 0
            if alive:
                rwd_alive += 0.02

            reward = rwd_resources + rwd_kill + rwd_exploration + rwd_food_and_water + rwd_equip + rwd_level + rwd_alive
            # print("---------------------------------")
            # print("resources: ", rwd_resources)
            # print("kill: ", rwd_kill)
            # print("exploration: ", rwd_exploration)
            # print("food_and_water: ", rwd_food_and_water)
            # print("equip: ", rwd_equip)
            # print("level: ", rwd_level)
            # print("alive: ", rwd_alive)
            # print("---------------------------------")

        else:
            done = True
            reward = 0
            info = {}
            new_my_obs = (np.zeros((129, 129, 40)), np.zeros(88))
        #         print(done)
        return new_my_obs, reward, done, info
